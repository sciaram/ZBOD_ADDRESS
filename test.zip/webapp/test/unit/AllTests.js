sap.ui.define([
	"test/test/test/unit/controller/master.controller"
], function () {
	"use strict";
});